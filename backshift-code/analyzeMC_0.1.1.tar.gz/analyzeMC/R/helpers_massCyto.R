
parseDescription <- function(description.df, dataSets, experiments){
  if(dataSets == "BND"){
    df <- as.data.frame(t(sapply(description.df$Description, function(i) parseOneElementBND(as.character(i)))))
    df <- data.frame(description.df$ExpInd, description.df$Description, df)
    colnames(df) <- c("ExpInd", "Description","cellType", "activator", "donor")
    df
  }else if(dataSets == "BM"){
    df <- as.data.frame(t(sapply(description.df$Description, 
                                 function(i) parseOneElementBM(experiments, as.character(i)))))
    df <- data.frame(ExpInd = description.df$ExpInd,Description = description.df$Description, df)
    # colnames(df) <- c("ExpInd", "Description","cellType", "expCondition", "donor")
    df
  }else{
    stop(paste("dataSets", dataSets, "not supported"))
  }
}


parseOneElementBND <- function(des.i){
  des.i.splitted <- strsplit(des.i, "_")[[1]]
  nElements <- length(des.i.splitted)
  donor <- sub(".mat", "", des.i.splitted[nElements])
  expCondition <- des.i.splitted[nElements-1]
  cellType <- paste(des.i.splitted[1:(nElements-2)], collapse = "_")
  c(cellType, expCondition, donor)
}


parseOneElementBM <- function(experiments, des.i){
  des.i.splitted <- strsplit(des.i, "_")[[1]]
  nElements <- length(des.i.splitted)
  activator <- sub(".mat", "", des.i.splitted[nElements])
  cellType <- des.i.splitted[nElements-1]
  if(experiments == "time"){
    expCondition <- c(time = paste(des.i.splitted[1:2], collapse = "_"))
     
  }else if(experiments == "8donor"){
    expCondition <- c(donor = des.i.splitted[1])
  }else if(experiments == "inhibitor"){
    dosage <- des.i.splitted[2]
    inhibitor <- des.i.splitted[1]
    expCondition <- c(inhibitor = inhibitor, dosage = dosage)    
  }else{
    stop(paste("experiments", experiments, "not supported. Needs to be 
               'time', '8donor', or 'inhibitor'"))
  }
  c(cellType = cellType, activator = activator, expCondition)
}


groupDonors <- function(donorIdx, merge, X, ExpInd, description){
  if(length(donorIdx) == 1){
    expIndSelect <- grep(donorIdx, description$donor)
    indicesSelect <- is.element(ExpInd, expIndSelect)
    ExpInd <- ExpInd[indicesSelect]
    X <- X[indicesSelect,]
  }else if(length(donorIdx) > 1 && mergeExpInd){
    ExpIndNew <- factor(Duplicated(description$expCondition))
    ExpInd <- sapply(ExpInd, function(i) ExpIndNew[which(i == description$ExpInd)])
    description$ExpInd <- ExpIndNew
  }

  list(X = X, ExpInd = ExpInd, ExpIndDescription = description)
}
