runCCNcytometryPar <- function(dataPath, selInhibitor, selDosage, selDonor, seed, CCNOptions, runID,
                            saveResultsPath, verbose = FALSE,
                            removeActs = NULL, keepActs = NULL, removeVars = NULL, keepVars = NULL){

  ### read data
  dat <- readRDS(dataPath)
  ### select inhibitor
  dat <- selectSubset(selInhibitor, which(colnames(dat$ExpIndDescription) == "inhibitor"), dat)
  ### select dosage
  dat <- selectSubsets(selDosage, which(colnames(dat$ExpIndDescription) == "dosage"), dat)
  ### select donor
  dat <- selectSubset(selDonor, which(colnames(dat$ExpIndDescription) == "donor"), dat)

  ### select / remove activators
  if(!missing(removeActs) & !is.null(removeActs)){
    if(verbose) cat(paste("\nRemoving activators", paste(removeActs, collapse = ", ")))
    keepActs <- setdiff(as.character(dat$ExpIndDescription$activator), removeActs)
  }
  if(exists("keepActs") & !is.null(keepActs)){
    if(verbose) cat(paste("\nKeeping activators", paste(keepActs, collapse = ", ")))
    dat <- if(length(keepActs) > 1){
      selectSubsets(keepActs, which(colnames(dat$ExpIndDescription) == "activator"), dat)
    }else{
      selectSubset(keepActs, which(colnames(dat$ExpIndDescription) == "activator"), dat)
    }
  }

  designMat <- dat$X
  ExpInd <- dat$ExpInd
  description <- dat$ExpIndDescription
  rm(dat)

  # select / remove variables
  if(!missing(removeVars) & !is.null(removeVars)){
    if(verbose) cat(paste("\nRemoving variables:\n", paste(removeVars, collapse = ", ")))
    keepVars <- setdiff(colnames(designMat), removeVars)
  }
  if(exists("keepVars") & !is.null(keepVars)){
    if(verbose) cat(paste("\nKeeping variables:\n", paste(keepVars, collapse = ", ")))
    keepVarsInd <- which(is.element(colnames(designMat), keepVars))
    designMat <- designMat[,keepVarsInd]
  }

  # check dimensions
  if(dim(designMat)[1] != length(ExpInd)) stop("Selection went wrong -- design matrix does not
                                               have same length as ExpInd.")

  set.seed(seed)

  # run method
  if(verbose) cat(paste("\nRunning", CCNOptions$method, "...\n"))

  res <- try(backShift(designMat, ExpInd,
                       ev = CCNOptions$options$ev,
                       covariance = CCNOptions$options$covariance,
                       nsim = CCNOptions$options$nsim,
                       threshold = CCNOptions$options$threshold,
                       verbose = verbose))

  if(!(inherits(res, "try-error")) & sum(res$Ahat) != 0){
    # visualize results
    uniqueExps <- unique(ExpInd)

    if(CCNOptions$method == "backShift"){
      if(verbose) cat("\nComputing success of joint diagonalization...\n")
      diagonalization <- vector("list", length(uniqueExps))
      descriptionExps <- NULL
      for(i in seq_along(uniqueExps)){
        diagonalization[[i]] <- backShift::computeDiagonalization(estConnectivity = res$Ahat, X = designMat, env = ExpInd,
                                       whichEnv = uniqueExps[i])
        descriptionExps <- c(descriptionExps,
                             as.character(description[description$ExpInd == uniqueExps[i],"Description"]))
      }
    }else{
      diagonalization <- NULL
    }


    # compute bootstrap
    if(CCNOptions$method == "backShift"){
      if(verbose)
        cat("\nRunning parametric bootstrap to determine success of joint diagonalization...")
      bootsRes <- bootstrapBackShift(res$Ahat, designMat, ExpInd, CCNOptions$nrep, verbose = verbose)
      if(verbose) cat(paste("\nJoint diagonalization successful?", bootsRes$jointDiagSuccess, "\n"))
    }


  }else{
    res <- NULL
  }

  settings <- list(dataPath = dataPath,
                   selInhibitor = selInhibitor,
                   selDosage = selDosage,
                   selDonor = selDonor,
                   seed = seed,
                   CCNOptions = CCNOptions,
                   runID = runID,
                   saveResultsPath = saveResultsPath,
                   verbose = verbose,
                   removeActs = removeActs,
                   keepActs = keepActs,
                   removeVars = removeVars,
                   keepVars = keepVars,
                   descriptionExps = if(exists("descriptionExps")) descriptionExps else NULL)

  resList <- list(resBackShift = res,
                  diagonalization = if(exists("diagonalization")) diagonalization else NULL,
                  settings = settings,
                  resBackShiftBoots = if(exists("bootsRes")) bootsRes else NULL)

  resList
}
