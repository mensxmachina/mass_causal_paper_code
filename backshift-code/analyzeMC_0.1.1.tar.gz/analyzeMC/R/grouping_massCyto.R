selectSubset <- function(selectGroup, colIndDescription, dat){
  
  if(length(colIndDescription) == 0){
    dat
  }else{
    expIndSelect <- dat$ExpIndDescription$ExpInd[grep(selectGroup, dat$ExpIndDescription[,colIndDescription])]
    indicesSelect <- is.element(dat$ExpInd, expIndSelect)
    ExpInd <- dat$ExpInd[indicesSelect]
    X <- dat$X[indicesSelect,]
    description <- dat$ExpIndDescription[dat$ExpIndDescription[,colIndDescription] == selectGroup,]
    
    list(X = X, ExpInd = ExpInd, ExpIndDescription = description)
  }
}

selectSubsets <- function(selectGroups, colIndDescription, dat){
  
  datList <- lapply(selectGroups, selectSubset, colIndDescription, dat)
    
  X <- ExpInd <- description <- NULL    
  
  for(i in 1:length(datList)){
    X <- rbind(X, datList[[i]]$X)  
    ExpInd <- c(ExpInd, datList[[i]]$ExpInd)  
    description <- rbind(description, datList[[i]]$ExpIndDescription)  
  }
  
  list(X = X, ExpInd = ExpInd, ExpIndDescription = description)
}

