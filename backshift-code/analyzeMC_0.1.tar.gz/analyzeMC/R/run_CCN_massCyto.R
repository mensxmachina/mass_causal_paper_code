runCCNcytometry <- function(dataPath, selInhibitor, selDosage, selDonor, seed, CCNOptions, runID,
                            saveResultsPath, verbose = FALSE,
                            removeActs = NULL, keepActs = NULL, removeVars = NULL, keepVars = NULL){

  ### create folder for output
  if (file.exists(paste(saveResultsPath, runID, "/", sep = "/", collapse = "/"))) {
    cat(paste("Folder", runID, "exists in", saveResultsPath, "and is a directory.\n"))
  } else if (file.exists(paste(saveResultsPath, runID, sep = "/", collapse = "/"))) {
    cat(paste("Folder", runID, "exists in", saveResultsPath, "but is a file.\n"))
  } else {
    cat(paste("Folder", runID, "does not exist in", saveResultsPath, "- creating.\n"))
    dir.create(file.path(saveResultsPath, runID))
  }

  ### read data
  dat <- readRDS(dataPath)
  ### select inhibitor
  dat <- selectSubset(selInhibitor, which(colnames(dat$ExpIndDescription) == "inhibitor"), dat)
  ### select dosage
  dat <- selectSubset(selDosage, which(colnames(dat$ExpIndDescription) == "dosage"), dat)
  ### select donor
  dat <- selectSubset(selDonor, which(colnames(dat$ExpIndDescription) == "donor"), dat)

  ### select / remove activators
  if(!missing(removeActs) & !is.null(removeActs)){
    if(verbose) cat(paste("\nRemoving activators", paste(removeActs, collapse = ", ")))
    keepActs <- setdiff(as.character(dat$ExpIndDescription$activator), removeActs)
  }
  if(exists("keepActs") & !is.null(keepActs)){
    if(verbose) cat(paste("\nKeeping activators", paste(keepActs, collapse = ", ")))
    dat <- selectSubsets(keepActs, which(colnames(dat$ExpIndDescription) == "activator"), dat)
  }

  designMat <- dat$X
  ExpInd <- dat$ExpInd
  description <- dat$ExpIndDescription
  rm(dat)

  # select / remove variables
  if(!missing(removeVars) & !is.null(removeVars)){
    if(verbose) cat(paste("\nRemoving variables:\n", paste(removeVars, collapse = ", ")))
    keepVars <- setdiff(colnames(designMat), removeVars)
  }
  if(exists("keepVars") & !is.null(keepVars)){
    if(verbose) cat(paste("\nKeeping variables:\n", paste(keepVars, collapse = ", ")))
    keepVarsInd <- which(is.element(colnames(designMat), keepVars))
    designMat <- designMat[,keepVarsInd]
  }

  # check dimensions
  if(dim(designMat)[1] != length(ExpInd)) stop("Selection went wrong -- design matrix does not
                                               have same length as ExpInd.")

  set.seed(seed)

  # run method
  if(verbose) cat(paste("\nRunning", CCNOptions$method, "...\n"))
#   res <- list()
#   res$Ahat <- getParents(designMat,
#                     environment = ExpInd,
#                     method = CCNOptions$method,
#                     setOptions = CCNOptions$options,
#                     verbose = verbose)
  res <- try(backShift(designMat, ExpInd,
                   ev = CCNOptions$options$ev,
                   nsim = CCNOptions$options$nsim,
                   threshold = CCNOptions$options$threshold,
                   verbose = verbose))

  if(!(inherits(res, "try-error")) & sum(res$Ahat) != 0){
    # visualize results
    uniqueExps <- unique(ExpInd)

    if(CCNOptions$method == "backShift"){
      if(verbose) cat("\nPlotting success of joint diagonalization...\n")
      pdf(file = paste(saveResultsPath, runID, "/", runID, "_jointDiag.pdf", sep = ""))
      for(i in seq_along(uniqueExps)){
        backShift::plotDiagonalization(estConnectivity = res$Ahat, X = designMat, env = ExpInd,
                                       whichEnv = uniqueExps[i],
                                       main = description[description$ExpInd == uniqueExps[i],"Description"]
        )
      }
      dev.off()
    }


    # compute bootstrap
    if(CCNOptions$method == "backShift"){
      if(verbose)
        cat("\nRunning parametric bootstrap to determine success of joint diagonalization...")
      bootsRes <- bootstrapBackShift(res$Ahat, designMat, ExpInd, CCNOptions$nrep, verbose = verbose)
      offDiagsbackShift <- bootsRes$sumOffDiagsBackShift

      pdf(file = paste(saveResultsPath, runID, "/", runID, "_bootstrapJointDiag.pdf", sep = ""))
      hist(bootsRes$bootsSumOffDiags, breaks = 100)
      abline(v = offDiagsbackShift, col = 2)
      abline(v = bootsRes$lower, col = "blue")
      abline(v = bootsRes$upper, col = "blue")
      dev.off()

      if(verbose) cat(paste("\nJoint diagonalization successful?", bootsRes$jointDiagSuccess, "\n"))
    }

    # extract estimates
    Ahat <- res$Ahat
    Ahat.structure <- res$AhatAdjacency
    thres.pe <- CCNOptions$thres.pe
    thres <- CCNOptions$options$threshold

    if(verbose) cat("\nPlotting point estimate, thresholded at", thres.pe,"... \n")
    pdf(file = paste(saveResultsPath, runID, "/", runID, "_network.pdf", sep = ""))
    plotGraphEdgeAttr(estimate = Ahat, plotStabSelec = FALSE, labels = colnames(designMat),
                      thres.point = thres.pe, thres.stab = thres,
                      main = paste("Point estimate thresholded at", thres.pe),
                      vertex.label.cex = 1.5, vertex.size = 20)

    if(!is.null(Ahat.structure)){
      if(verbose) cat("Plotting stability selection result... \n")
      plotGraphEdgeAttr(estimate = Ahat.structure, plotStabSelec = TRUE,
                        labels = colnames(designMat), thres.point = thres.pe,
                        edgeWeights = Ahat, thres.stab = thres,
                        main = "Stability selection result",
                        vertex.label.cex = 1.5, vertex.size = 20)
    }
    dev.off()
  }else{
    res <- NULL
  }

  settings <- list(dataPath = dataPath,
                   selInhibitor = selInhibitor,
                   selDosage = selDosage,
                   selDonor = selDonor,
                   seed = seed,
                   CCNOptions = CCNOptions,
                   runID = runID,
                   saveResultsPath = saveResultsPath,
                   verbose = verbose,
                   removeActs = removeActs,
                   keepActs = keepActs,
                   removeVars = removeVars,
                   keepVars = keepVars,
                   uniqueExps = uniqueExps)

  resList <- list(resBackShift = res,
                  settings = settings,
                  resBackShiftBoots = if(exists("bootsRes")) bootsRes else NULL)

  saveRDS(resList, file = paste(saveResultsPath, runID, "/", runID, "_res.rds", sep = ""))
}
