createPlotsCytoInhibitor <- function(results, verbose = FALSE){

  for(i in seq_along(results)){
    if(class(results[[i]]) != "try-error"){
      saveResultsPath <- results[[i]]$settings$saveResultsPath
      settings <- results[[i]]$settings
      runID <- settings$runID
      res <- results[[i]]$resBackShift
      CCNOptions <- settings$CCNOptions


      ### create folder for output
      if (file.exists(paste(saveResultsPath, runID, "/", sep = "/", collapse = "/"))) {
        cat(paste("Folder", runID, "exists in", saveResultsPath, "and is a directory.\n"))
      } else if (file.exists(paste(saveResultsPath, runID, sep = "/", collapse = "/"))) {
        cat(paste("Folder", runID, "exists in", saveResultsPath, "but is a file.\n"))
      } else {
        cat(paste("Folder", runID, "does not exist in", saveResultsPath, "- creating.\n"))
        dir.create(file.path(saveResultsPath, runID))
      }


      if(!(inherits(res, "try-error")) & sum(res$Ahat) != 0){
        # visualize results

        if(CCNOptions$method == "backShift"){

          diagonalization <- results[[i]]$diagonalization
          descriptionExps <- results[[i]]$settings$descriptionExps
          nUniqueExps <- length(results[[i]]$diagonalization)


          if(verbose) cat("\nPlotting success of joint diagonalization...\n")
          pdf(file = paste(saveResultsPath, runID, "/", runID, "_jointDiag.pdf", sep = ""))
          for(k in 1:nUniqueExps){
            fields::image.plot(z = diagonalization[[k]],
                               col = fields::tim.colors(),
                               legend.shrink = 0.8,
                               main = descriptionExps[k])
          }
          dev.off()
        }


        # compute bootstrap
        if(CCNOptions$method == "backShift"){
          bootsRes <- results[[i]]$resBackShiftBoots
          offDiagsbackShift <- bootsRes$sumOffDiagsBackShift

          pdf(file = paste(saveResultsPath, runID, "/", runID, "_bootstrapJointDiag.pdf", sep = ""))
          hist(bootsRes$bootsSumOffDiags, breaks = 100)
          abline(v = offDiagsbackShift, col = 2)
          abline(v = bootsRes$lower, col = "cyan")
          abline(v = bootsRes$upper, col = "blue")
          abline(v = bootsRes$lowerBasic, col = "lightgreen")
          abline(v = bootsRes$upperBasic, col = "darkgreen")
          dev.off()

          if(verbose) cat(paste("\nJoint diagonalization successful?", bootsRes$jointDiagSuccess, "\n"))
        }

        # extract estimates
        Ahat <- res$Ahat
        Ahat.structure <- res$AhatAdjacency
        thres.pe <- CCNOptions$thres.pe
        thres <- CCNOptions$options$threshold

        if(verbose) cat("\nPlotting point estimate, thresholded at", thres.pe,"... \n")
        pdf(file = paste(saveResultsPath, runID, "/", runID, "_network.pdf", sep = ""))
        plotGraphEdgeAttr(estimate = Ahat, plotStabSelec = FALSE, labels = colnames(Ahat),
                          thres.point = thres.pe, thres.stab = thres,
                          main = paste("Point estimate thresholded at", thres.pe),
                          vertex.label.cex = 1.5, vertex.size = 20)

        if(!is.null(Ahat.structure)){
          if(verbose) cat("Plotting stability selection result... \n")
          plotGraphEdgeAttr(estimate = Ahat.structure, plotStabSelec = TRUE,
                            labels = colnames(Ahat.structure), thres.point = thres.pe,
                            edgeWeights = Ahat, thres.stab = thres,
                            main = "Stability selection result",
                            vertex.label.cex = 1.5, vertex.size = 20)
        }
        dev.off()
      }

      resList <- list(resBackShift = res,
                      diagonalization = if(exists("diagonalization")) diagonalization else NULL,
                      settings = settings,
                      resBackShiftBoots = if(exists("bootsRes")) bootsRes else NULL)

      saveRDS(resList, file = paste(saveResultsPath, runID, "/", runID, "_res.rds", sep = ""))

    }
  }
}
