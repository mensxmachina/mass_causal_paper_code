aggregateResults <- function(resultPath, thresConv, takeout, woInhibitors,
                             allInhibitors, allActs,  saveResultsPath,folderName){
  allFiles <- list.files(resultPath, full.names = TRUE, include.dirs = TRUE,
                         recursive = TRUE)
  rdsFiles <- allFiles[grep(".rds", allFiles)]
  rdsFiles <- if(takeout != "" & length(grep(takeout, rdsFiles)) > 0) rdsFiles[-c(grep(takeout, rdsFiles))] else rdsFiles

  resToKeep <- list()
  j <- 0
  boots <- 0
  fileRunsConverged <- NULL
  fileRunsContributed <- NULL


  for(i in seq_along(rdsFiles)){
    res.i <- readRDS(rdsFiles[i])
    if(!is.null(res.i$resBackShift)){
      if(res.i$resBackShift$percentageOfRunsConverged > thresConv){
        if(res.i$resBackShiftBoots$sumOffDiagsBackShift <= res.i$resBackShiftBoots$upper){
          if(!is.element(res.i$settings$selInhibitor, woInhibitors)){
            j <- j + 1
            resToKeep[[j]] <- res.i
            fileRunsConverged <- c(fileRunsConverged, rdsFiles[i])
          }

        }
      }
      if(res.i$resBackShiftBoots$sumOffDiagsBackShift < res.i$resBackShiftBoots$upper){
        boots <- boots + 1
      }
    }
  }

  if(length(resToKeep) > 0){
    runToGetOptions <- resToKeep[[1]]
    p <- nrow(runToGetOptions$resBackShift$Ahat)
    colNames <- colnames(runToGetOptions$resBackShift$Ahat)
    df <- expand.grid(colNames, colNames)
    colnames(df) <- c("from", "to")
    cov <- runToGetOptions$settings$CCNOptions$options$covariance

    actIndCombs <- expand.grid(allInhibitors, allActs)
    colnames(actIndCombs) <- c("Inhibitor", "Activator")
    actIndCombs$foundEffect <- rep(0, nrow(actIndCombs))
    actIndCombs$numSelected <- rep(0, nrow(actIndCombs))


    resList <- vector("list", nrow(df))
    for(i in 1:nrow(df)){
      resList[[i]]$from <- as.character(df[i, "from"])
      resList[[i]]$to <- as.character(df[i, "to"])
      resList[[i]]$actIndCombs <- actIndCombs
    }

    jointAdjacency <- matrix(0, ncol = p, nrow = p)

    for(i in seq_along(resToKeep)){
      res.i <- resToKeep[[i]]
      adjacency <- res.i$resBackShift$AhatAdjacency
      entries <- melt(adjacency)
      listInd <- which(entries$value > 0)

      for(e in seq_along(listInd)){
        resList[[listInd[e]]]$actIndCombs[resList[[listInd[e]]]$actIndCombs$Inhibitor == res.i$settings$selInhibitor &
                                            resList[[listInd[e]]]$actIndCombs$Activator == res.i$settings$keepActs, "foundEffect"] <- 1

        resList[[listInd[e]]]$actIndCombs[resList[[listInd[e]]]$actIndCombs$Inhibitor == res.i$settings$selInhibitor &
                                            resList[[listInd[e]]]$actIndCombs$Activator == res.i$settings$keepActs, "numSelected"] <- entries[listInd[e], "value"]

      }

      jointAdjacency <- jointAdjacency + adjacency

      if(sum(adjacency) != 0){
        fileRunsContributed <- c(fileRunsContributed, res.i$settings$runID)
      }
    }


    ### create folder for output
    if (file.exists(paste(saveResultsPath,
                          folderName,
                          "/", sep = "/", collapse = "/"))) {
      cat(paste("Folder", folderName,
                "exists in", saveResultsPath, "and is a directory.\n"))
    } else if (file.exists(paste(saveResultsPath,
                                 folderName,
                                 sep = "/", collapse = "/"))) {
      cat(paste("Folder", folderName,
                "exists in", saveResultsPath, "but is a file.\n"))
    } else {
      cat(paste("Folder", folderName,
                "does not exist in", saveResultsPath, "- creating.\n"))
      dir.create(file.path(saveResultsPath, folderName, "/", sep = ""))
    }



    table <- NULL

    for(i in 1:length(resList)){
      resList[[i]]$actIndCombs <- resList[[i]]$actIndCombs[resList[[i]]$actIndCombs$foundEffect > 0,]
      if(nrow(resList[[i]]$actIndCombs) > 0){
        temp <- resList[[i]]$actIndCombs
        to_write <- data.frame(from = resList[[i]]$from, to = resList[[i]]$to)
        to_write <- cbind(to_write, temp)
        table <- rbind(table, to_write)
        write.table(to_write,
                    paste(saveResultsPath, folderName, "/", gsub(".rds", "", takeout),
                          "_", cov, "_effect_", resList[[i]]$from, "_", resList[[i]]$to,
                          ".txt", sep = ""), row.names = FALSE)
      }
    }

    latex(format(table[, - (ncol(table)-1)], digits =3), rowname = NULL,
          file = paste(saveResultsPath, folderName, "/", gsub(".rds", "", takeout),
                       "_", cov, "_effect_", resList[[i]]$from, "_", resList[[i]]$to, ".tex",
                       sep = ""))


    saveRDS(table, paste(saveResultsPath, folderName, "/", gsub(".rds", "", takeout),
                      "_", cov, "_effect_", resList[[i]]$from, "_", resList[[i]]$to,
                      ".rds", sep = ""))


    jointAdjacencyNorm <- jointAdjacency/length(resToKeep)
    pdf(file = paste(saveResultsPath, folderName, "/", gsub(".rds", "", takeout), "_", cov,
                     "_network.pdf", sep = ""), height = 10, width = 10)
    plotGraphEdgeAttr(estimate = jointAdjacencyNorm, plotStabSelec = FALSE,
                      labels = colnames(jointAdjacencyNorm), thres.point = 0.25,
                      main = "Averaged stability selection result",
                      vertex.label.cex = 1, vertex.size = 15)
    dev.off()

    allResults <- list(fileRunsConverged = fileRunsConverged,
             fileRunsContributed = fileRunsContributed,
             jointAdjacencyNorm = jointAdjacencyNorm,
             jointAdjacency = jointAdjacency,
             table = table)
  }else{
    allResults <- list(fileRunsConverged = NULL,
                     fileRunsContributed = NULL,
                     jointAdjacencyNorm = NULL,
                     jointAdjacency = NULL,
                     table = NULL)
  }

  saveRDS(object = allResults, paste(saveResultsPath,
                                     "resultsAll_",
                                     gsub(".rds", "", takeout),
                                     ".rds", sep = ""))
  allResults
}


